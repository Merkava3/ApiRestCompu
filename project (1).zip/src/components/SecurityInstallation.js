const SecurityInstallation = () => {
  return (
    <section className="py-16 px-4 bg-white">
      <div className="max-w-6xl mx-auto">
        <div className="bg-gradient-to-r from-blue-900 to-blue-700 rounded-xl p-8 text-white shadow-xl">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <h2 className="text-3xl font-bold mb-4">Instalación Profesional de Cámaras de Seguridad</h2>
              <p className="text-lg mb-6">
                Sistemas completos con monitoreo remoto 24/7 y almacenamiento en la nube.
              </p>
              <button className="bg-white text-blue-900 px-6 py-3 rounded-lg font-medium hover:bg-blue-100 transition">
                Solicitar Cotización
              </button>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <div className="text-8xl">📹</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SecurityInstallation;