import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import RepairServices from './components/RepairServices';
import RepairStatus from './components/RepairStatus';
import ProductShowcase from './components/ProductShowcase';
import SecurityInstallation from './components/SecurityInstallation';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        <HeroSection />
        <RepairServices />
        <RepairStatus />
        <ProductShowcase />
        <SecurityInstallation />
      </main>
      <Footer />
    </div>
  );
}

export default App;

// DONE