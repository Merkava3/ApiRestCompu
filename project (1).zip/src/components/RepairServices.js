const RepairServices = () => {
  const services = [
    { name: "Reparación de Laptops", icon: "💻" },
    { name: "Reparación de PCs", icon: "🖥️" },
    { name: "Reparación de Dispositivos Electrónicos", icon: "🔌" },
    { name: "Reparación de Tablets", icon: "📲" },
    { name: "Instalación de Cámaras", icon: "📹" },
  ];

  return (
    <section className="py-16 px-4 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">Servicios de Reparación y Mantenimiento</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <div key={index} className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition hover:border-l-4 hover:border-blue-700">
              <div className="text-4xl mb-4 text-blue-600">{service.icon}</div>
              <h3 className="text-xl font-semibold mb-2 text-gray-800">{service.name}</h3>
              <p className="text-gray-600">Servicio profesional con garantía escrita</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default RepairServices;