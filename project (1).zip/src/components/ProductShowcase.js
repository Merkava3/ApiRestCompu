const ProductShowcase = () => {
  const products = [
    { name: "Teclado Mecánico RGB", price: 899, category: "Periféricos" },
    { name: "Mouse Gamer Profesional", price: 599, category: "Periféricos" },
    { name: "Disco SSD 500GB", price: 1299, category: "Almacenamiento" },
    { name: "Memoria RAM 16GB DDR4", price: 1099, category: "Componentes" },
  ];

  return (
    <section className="py-16 px-4 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">Productos Tecnológicos</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product, index) => (
            <div key={index} className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition hover:translate-y-[-4px]">
              <div className="h-48 bg-gray-200 flex items-center justify-center">
                <span className="text-4xl">🖥️</span>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2 text-gray-800">{product.name}</h3>
                <p className="text-gray-600 mb-4">{product.category}</p>
                <p className="text-2xl font-bold text-blue-700">${product.price.toLocaleString()}</p>
                <button className="mt-4 w-full bg-blue-700 text-white py-2 rounded-lg hover:bg-blue-800 transition font-medium">
                  Agregar al carrito
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductShowcase;