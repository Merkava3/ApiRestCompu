import { useState, useEffect } from 'react';

const HeroSection = () => {
  const slides = [
    {
      image: "https://images.unsplash.com/photo-1517430816045-df4b7de11d1d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1471&q=80",
      alt: "Técnicos reparando dispositivos"
    },
    {
      image: "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1632&q=80",
      alt: "Productos tecnológicos"
    },
    {
      image: "https://images.unsplash.com/photo-1563986768609-322da13575f3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
      alt: "Instalación de cámaras de seguridad"
    }
  ];

  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
    }, 5000);
    return () => clearInterval(interval);
  }, [slides.length]);

  return (
    <div className="relative h-[500px] overflow-hidden">
      {/* Slider de imágenes */}
      <div className="absolute inset-0 flex transition-transform duration-1000 ease-in-out"
           style={{ transform: `translateX(-${currentSlide * 100}%)` }}>
        {slides.map((slide, index) => (
          <div key={index} className="w-full flex-shrink-0 h-full">
            <img src={slide.image} alt={slide.alt} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black bg-opacity-40"></div>
          </div>
        ))}
      </div>
      
      {/* Contenido sobre el slider */}
      <div className="relative z-10 h-full flex items-center justify-center text-center px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex justify-center mb-8">
            <div className="bg-white p-4 rounded-lg shadow-lg">
              <div className="text-3xl font-bold text-blue-900">
                <span className="text-blue-600">TECNO</span>
                <span className="text-gray-800">EXPRESS</span>
              </div>
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-6 text-white">Soluciones Tecnológicas Integrales</h1>
          <p className="text-xl mb-8 text-white">Reparación experta, productos de calidad e instalaciones profesionales</p>
          <div className="flex flex-wrap justify-center gap-4">
            <button className="bg-white text-blue-900 px-6 py-3 rounded-lg font-medium hover:bg-blue-100 transition">
              Nuestros Servicios
            </button>
            <button className="border-2 border-white px-6 py-3 rounded-lg font-medium hover:bg-white hover:text-blue-900 transition text-white">
              Ver Productos
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;